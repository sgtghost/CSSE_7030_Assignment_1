"""
CSSE1001 Assignment 1
Semester 2, 2020
"""

from a1_support import *

# Fill these in with your details
__author__ = "{{user.name}} ({{user.id}})"
__email__ = ""
__date__ = ""



# Write your code here (i.e. functions)


def main():
    """
    Handles top-level interaction with user.
    """
    # Write the code for your main function here



if __name__ == "__main__":
    main()